plugins {
    id("com.android.application") // Apply Android application plugin
    id("org.jetbrains.kotlin.android") // Apply Kotlin Android plugin
    id("com.google.gms.google-services") // Apply Google Services plugin for Firebase integration
}

android {
    namespace = "com.example.japaneseflash"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.japaneseflash"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        multiDexEnabled = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation (platform("com.google.firebase:firebase-bom:28.3.1")) // Use the latest version
    implementation("com.google.firebase:firebase-firestore") // Removes jetification

    // Core Android libraries
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.android.material:material:1.8.0")
    implementation("androidx.recyclerview:recyclerview:1.2.1")

    // Lifecycle components
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.5.1")

    // Retrofit dependencies (if used for API calls)
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")

    // Kotlin standard library
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.9.0")

    // Firebase dependencies with exclusion to avoid conflicts
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-firestore") {
        exclude(group = "com.google.firebase", module = "firebase-common")
    }

    // Additional dependencies
    implementation(libs.monitor)
    implementation(libs.androidx.junit)
    implementation(libs.activity)
    testImplementation(libs.junit.jupiter)
    testImplementation(libs.testng)
}


// Ensure Google Services plugin is applied if Firebase is being used
apply(plugin = "com.google.gms.google-services")