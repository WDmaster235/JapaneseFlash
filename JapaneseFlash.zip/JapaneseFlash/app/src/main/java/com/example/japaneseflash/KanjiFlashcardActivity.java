package com.example.japaneseflash;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class KanjiFlashcardActivity extends AppCompatActivity {

    private TextView kanjiTextView;
    private TextView meaningTextView;
    private List<String> kanjiList = new ArrayList<>();
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanji_flashcard); // Ensure the layout file is named correctly

        kanjiTextView = findViewById(R.id.kanji_text);
        meaningTextView = findViewById(R.id.meaning_text);
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference("users").child(currentUser.getUid()).child("kanjiCards");

        loadKanjiList();

        // Set up Next Button functionality
        findViewById(R.id.next_button).setOnClickListener(v -> showRandomKanji());

        // Set up Home Button functionality
        findViewById(R.id.home_button).setOnClickListener(v -> {
            if (currentUser != null) {
                startActivity(new Intent(KanjiFlashcardActivity.this, Home.class));
            } else {
                startActivity(new Intent(KanjiFlashcardActivity.this, MainActivity.class));
            }
        });

        // Set up Save Card Button functionality
        findViewById(R.id.save_card_button).setOnClickListener(v -> saveCurrentKanji());
    }

    @SuppressLint("NewApi")
    private void loadKanjiList() {
        // URL for Kanji API to fetch Jōyō Kanji list
        String url = "https://kanjiapi.dev/v1/kanji/joyo";
        new GetKanjiListTask().execute(url);
    }

    @SuppressLint("NewApi")
    private class GetKanjiListTask extends AsyncTask<String, Void, List<String>> {

        @Override
        protected List<String> doInBackground(String... urls) {
            List<String> kanjiList = new ArrayList<>();
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setConnectTimeout(10000);
                urlConnection.setReadTimeout(10000);
                urlConnection.connect();

                // Read the response from the input stream
                InputStreamReader inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
                reader = new BufferedReader(inputStreamReader);
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                // Parse the JSON response
                JSONArray jsonArray = new JSONArray(stringBuilder.toString());
                for (int i = 0; i < jsonArray.length(); i++) {
                    kanjiList.add(jsonArray.getString(i));
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return kanjiList;
        }

        @Override
        protected void onPostExecute(List<String> result) {
            if (result != null && !result.isEmpty()) {
                kanjiList = result;
                showRandomKanji(); // Show a random Kanji from the list
            } else {
                Toast.makeText(KanjiFlashcardActivity.this, "Failed to load Kanji", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showRandomKanji() {
        if (kanjiList != null && !kanjiList.isEmpty()) {
            // Select a random Kanji from the list
            String randomKanji = kanjiList.get((int) (Math.random() * kanjiList.size()));

            // Flip-out the current Kanji
            kanjiTextView.animate().rotationY(90f).setDuration(300).withEndAction(() -> {
                kanjiTextView.setText(randomKanji);
                // Flip-in the new Kanji
                kanjiTextView.animate().rotationY(0f).setDuration(300);
            });

            loadKanjiDetails(randomKanji); // Load details for the selected Kanji
        }
    }

    private void loadKanjiDetails(String character) {
        // URL for Kanji API to fetch Kanji details
        String url = "https://kanjiapi.dev/v1/kanji/" + character;
        new GetKanjiDetailsTask().execute(url);
    }

    private class GetKanjiDetailsTask extends AsyncTask<String, Void, Kanji> {

        @Override
        protected Kanji doInBackground(String... urls) {
            Kanji kanji = null;
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setConnectTimeout(10000);
                urlConnection.setReadTimeout(10000);
                urlConnection.connect();

                // Read the response from the input stream
                InputStreamReader inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
                reader = new BufferedReader(inputStreamReader);
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                // Parse the JSON response
                JSONObject jsonObject = new JSONObject(stringBuilder.toString());
                kanji = new Kanji();
                kanji.setCharacter(jsonObject.getString("kanji"));
                kanji.setKunReadings(parseJsonArray(jsonObject.getJSONArray("kun_readings")));
                kanji.setOnReadings(parseJsonArray(jsonObject.getJSONArray("on_readings")));
                kanji.setMeanings(parseJsonArray(jsonObject.getJSONArray("meanings")));
                kanji.setGrade(jsonObject.optInt("grade"));
                kanji.setJlpt(jsonObject.optInt("jlpt"));
                kanji.setStrokeCount(jsonObject.optInt("stroke_count"));
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return kanji;
        }

        @Override
        protected void onPostExecute(Kanji kanji) {
            if (kanji != null) {
                displayKanjiDetails(kanji);
            } else {
                Toast.makeText(KanjiFlashcardActivity.this, "Failed to load Kanji details", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private List<String> parseJsonArray(JSONArray jsonArray) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                list.add(jsonArray.getString(i));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    private void displayKanjiDetails(Kanji kanji) {
        if (kanji != null) {
            String character = kanji.getCharacter();
            String meaning = String.join(", ", kanji.getMeanings());

            // Update the UI with Kanji details
            kanjiTextView.setText(character);
            meaningTextView.setText(meaning);
        }
    }

    private void saveCurrentKanji() {
        String currentKanji = kanjiTextView.getText().toString();
        if (!currentKanji.isEmpty()) {
            databaseReference.child(currentKanji).setValue(true);
            Toast.makeText(this, "Kanji saved successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No Kanji to save!", Toast.LENGTH_SHORT).show();
        }
    }
}
