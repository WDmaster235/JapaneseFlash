package com.example.japaneseflash;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class KanjiMenu extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanji_menu); // Ensure the layout file is named correctly

        // Find and set up button listeners
        findViewById(R.id.joyokanji_button).setOnClickListener(v -> startFlashcardActivity("joyokanji"));
        findViewById(R.id.grade1_button).setOnClickListener(v -> startFlashcardActivity("grade1"));
        findViewById(R.id.grade2_button).setOnClickListener(v -> startFlashcardActivity("grade2"));
        findViewById(R.id.grade3_button).setOnClickListener(v -> startFlashcardActivity("grade3"));
        findViewById(R.id.grade4_button).setOnClickListener(v -> startFlashcardActivity("grade4"));
        findViewById(R.id.grade5_button).setOnClickListener(v -> startFlashcardActivity("grade5"));
        findViewById(R.id.grade6_button).setOnClickListener(v -> startFlashcardActivity("grade6"));
    }

    private void startFlashcardActivity(String category) {
        Intent intent = new Intent(KanjiMenu.this, KanjiFlashcardActivity.class);
        intent.putExtra("CATEGORY", category);
        startActivity(intent);
    }
}
