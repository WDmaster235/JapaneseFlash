package com.example.japaneseflash;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class KanjiAdapter extends RecyclerView.Adapter<KanjiAdapter.KanjiViewHolder> {
    private List<String> kanjiList;

    public KanjiAdapter(List<String> kanjiList) {
        this.kanjiList = kanjiList;
    }

    @Override
    public KanjiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_kanji, parent, false);
        return new KanjiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(KanjiViewHolder holder, int position) {
        String kanji = kanjiList.get(position);
        holder.kanjiTextView.setText(kanji);
    }

    @Override
    public int getItemCount() {
        return kanjiList.size();
    }

    public static class KanjiViewHolder extends RecyclerView.ViewHolder {
        TextView kanjiTextView;

        public KanjiViewHolder(View itemView) {
            super(itemView);
            //kanjiTextView = itemView.findViewById(R.id.kanji_text);
        }
    }
}
