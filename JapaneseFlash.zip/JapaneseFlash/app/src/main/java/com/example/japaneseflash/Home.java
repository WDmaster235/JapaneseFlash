package com.example.japaneseflash;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {

    private Button kanjiMenuButton, savedCardsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize buttons
        kanjiMenuButton = findViewById(R.id.kanji_menu_button);
        savedCardsButton = findViewById(R.id.saved_cards_button);

        // Set up button listeners
        kanjiMenuButton.setOnClickListener(v -> navigateToKanjiMenu());
        savedCardsButton.setOnClickListener(v -> navigateToSavedCards());
    }

    private void navigateToKanjiMenu() {
        startActivity(new Intent(Home.this, KanjiMenu.class));
    }

    private void navigateToSavedCards() {
        //Intent intent = new Intent(Home.this, SavedCards.class); // Navigate to your saved cards activity
        //startActivity(intent);
    }
}
