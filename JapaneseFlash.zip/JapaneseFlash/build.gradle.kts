plugins {
    //alias(libs.plugins.android.application) apply false
    //alias(libs.plugins.google.gms.google.services) apply false
    //id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "1.8.22" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}
